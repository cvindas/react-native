# React Native Expo Course

## Build

web

```
expo build:android
expo build:ios
expo build:web
```
