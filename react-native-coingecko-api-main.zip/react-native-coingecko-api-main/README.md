# CryptoMarket App
A simple react native app that uses CoinGecko API

![](./screenshot.png)
