import { App } from '@wow/common';

export default App;
