export { NativeRouter as Router, Route, Switch } from "react-router-native";
